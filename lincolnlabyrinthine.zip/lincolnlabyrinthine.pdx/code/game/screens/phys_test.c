// written by diskodev
// game/screens/phys_test.c
// Physics + collision showcase. Debug geometry overlay + tenkopd-reference slope physics.
#include "phys_test.h"
#include <engine/engine_core.h>
#include <engine/signage.h>
#include <game/data/world.h>
#include <game/data/objects.h>
#include <math.h>

extern PlaydateAPI*   pd;
extern InputManager   inputManager;
extern ScreenManager  screenManager;

// ---- Physics constants ----
#define PT_GRAVITY        780.0f
#define PT_JUMP_VEL      -260.0f
#define PT_DOUBLE_JUMP_VEL -300.0f
#define PT_MOVE_SPEED      60.0f
#define PT_RUN_SPEED      110.0f
#define PT_DOUBLE_TAP_FRAMES 8   // window to register double-tap direction
#define PT_MAX_FALL       460.0f
#define PT_BODY_W          10.0f
#define PT_BODY_H          14.0f
#define PT_SPAWN_X         32.0f
#define PT_SPAWN_Y        162.0f
#define PT_SLOPE_SNAP       4.0f   // px snap window for slope landing
#define PT_SPRING_VEL    -420.0f
#define PT_SPRING_FRAMES    6    // frames to show compressed spring sprite

typedef struct {
    f32 x, y, prevY;
    f32 vx, vy;
    bool onGround;
    bool facingRight;
    bool dropThrough;
    bool canDoubleJump;
    bool isRunning;
    i32  tapDir;          // last tapped direction: -1/0/1
    i32  tapFrames;       // frames since last tap (counts up)
    i32  tapDownFrames;   // frames since last down-tap
} PhysBody;

// ---- Animation ----
typedef enum { PS_IDLE, PS_WALK, PS_RUN, PS_CROUCH, PS_JUMP, PS_FALL } PlayerAnimState;

static AnimationSet    s_animSet;
static AnimationState  s_animState;
static PlayerAnimState s_animCur;

// ---- Crate physics ----
#define PT_MAX_CRATES    8
#define PT_CRATE_SIZE   ((f32)TILE_SIZE)
#define PT_CRATE_FRICTION 0.82f  // lateral damping when grounded
#define PT_CRATE_PUSH_VEL   55.0f  // velocity transferred to crate on player contact
#define PT_PUSH_SPEED        28.0f  // player max speed while pushing a crate
#define PT_STAMINA_DRAIN      0.6f  // per second while pushing
#define PT_STAMINA_REGEN      0.35f // per second while not pushing
#define PT_STAMINA_EXHAUST_T  0.8f  // seconds of lockout after stamina empties

typedef struct {
    f32 x, y, prevY;
    f32 vx, vy;
    bool onGround;
    bool active;
} CrateBody;

static CrateBody s_crates[PT_MAX_CRATES];
static i32       s_crateCount;
static f32       s_stamina      = 1.0f;  // 0..1
static f32       s_exhaustTimer = 0.0f;  // lockout countdown after depletion
static bool      s_isPushing    = false;

// ---- State ----
static PhysBody        s_body;
static LCDBitmapTable* s_objTable;
static i32 s_springTx = -1, s_springTy = -1, s_springFrames = 0;
static bool s_buttonActivated = false;
static bool s_inVent          = false;
static i32  s_ventTx = -1, s_ventTy = -1;

// Matches tenkopd GetSlopeSurfaceY exactly.
static f32 SlopeSurfaceY(CollisionType ct, f32 localX) {
    f32 x    = localX < 0.0f ? 0.0f : (localX > (f32)TILE_SIZE ? (f32)TILE_SIZE : localX);
    f32 half = (f32)TILE_SIZE * 0.5f;
    switch (ct) {
        case COL_SLOPE_UL:    return (f32)TILE_SIZE - x;          // / full
        case COL_SLOPE_UL_LO: return (f32)TILE_SIZE - (x * 0.5f); // / lower half
        case COL_SLOPE_UL_HI: return half - (x * 0.5f);           // / upper half
        case COL_SLOPE_UR_LO: return x * 0.5f;                    // \ lower half
        case COL_SLOPE_UR_HI: return half + (x * 0.5f);           // \ upper half
        case COL_SLOPE_UR:    return x;                            // \ full
        default:               return (f32)TILE_SIZE;
    }
}

static bool IsSlope(CollisionType ct) {
    switch (ct) {
        case COL_SLOPE_UL: case COL_SLOPE_UL_LO: case COL_SLOPE_UL_HI:
        case COL_SLOPE_UR_LO: case COL_SLOPE_UR_HI: case COL_SLOPE_UR:
            return true;
        default: return false;
    }
}

// ---- Collision helpers ----
static CollisionType TileAt(i32 tx, i32 ty) {
    return World_GetCollisionType(&gWorld, tx, ty);
}

static bool IsSolid(CollisionType ct) {
    return ct == COL_SOLID || ct == COL_SOLID_DUP;
}

// Returns true if stepping up tileTop is possible (space above is clear).
static bool TryStepUp(PhysBody* b, f32 tileTop) {
    if (b->vy < -5.0f) return false;  // don't step up while moving upward (e.g. spring launch)
    f32 stepH = (b->y + PT_BODY_H) - tileTop;
    if (stepH < 0.0f || stepH > (f32)TILE_SIZE) return false;
    f32 newY  = tileTop - PT_BODY_H;
    i32 tTop  = (i32)(newY / (f32)TILE_SIZE);
    i32 tBot  = (i32)((newY + PT_BODY_H - 0.5f) / (f32)TILE_SIZE);
    i32 tL    = (i32)(b->x / (f32)TILE_SIZE);
    i32 tR    = (i32)((b->x + PT_BODY_W - 0.5f) / (f32)TILE_SIZE);
    for (i32 cy = tTop; cy <= tBot; cy++)
        for (i32 cx = tL; cx <= tR; cx++)
            if (IsSolid(TileAt(cx, cy))) return false;
    b->y = newY;
    if (b->vy > 0.0f) b->vy = 0.0f;
    b->onGround = true;
    return true;
}

// Returns walkable surface Y for objects that block lateral movement, or -1 if none.
static f32 ObjectSolidSurface(i32 tx, i32 ty) {
    if (tx < 0 || tx >= WORLD_WIDTH_TILES || ty < 0 || ty >= WORLD_HEIGHT_TILES) return -1.0f;
    i32 obj = gWorld.tiles[LAYER_OBJECTS][ty][tx];
    f32 t   = (f32)(ty * TILE_SIZE);
    if (obj == OBJ_SPRING_A || obj == OBJ_SPRING_B) return t + (f32)TILE_SIZE * 0.50f;
    if (obj == OBJ_BUTTON_UP)                       return t + (f32)TILE_SIZE * 0.50f;
    if (obj == OBJ_BUTTON_DOWN)                     return t + (f32)TILE_SIZE * 0.75f;
    return -1.0f;
}

static void ResolveX(PhysBody* b) {
    i32 top = (i32)( b->y                  / (f32)TILE_SIZE);
    i32 bot = (i32)((b->y + PT_BODY_H - 0.5f) / (f32)TILE_SIZE);
    if (b->vx > 0.0f) {
        i32 right = (i32)((b->x + PT_BODY_W - 0.5f) / (f32)TILE_SIZE);
        for (i32 ty = top; ty <= bot; ty++) {
            CollisionType ct = TileAt(right, ty);
            f32 objSurf = (ct == COL_EMPTY) ? ObjectSolidSurface(right, ty) : -1.0f;
            // overlap: player body must enter the solid region [objSurf, tileBottom)
            bool objBlock = objSurf >= 0.0f
                && b->y < (f32)(ty * TILE_SIZE + TILE_SIZE)
                && b->y + PT_BODY_H > objSurf + 0.5f;
            if (IsSolid(ct) || ct == COL_HALF_BOTTOM || objBlock) {
                if (!objBlock) {
                    f32 tileTop = (f32)(ty * TILE_SIZE);
                    f32 surface = tileTop + (ct == COL_HALF_BOTTOM ? (f32)TILE_SIZE * 0.5f : 0.0f);
                    if (TryStepUp(b, surface)) return;
                }
                b->x  = (f32)(right * TILE_SIZE) - PT_BODY_W;
                b->vx = 0.0f;
                return;
            }
        }
    } else if (b->vx < 0.0f) {
        i32 left = (i32)(b->x / (f32)TILE_SIZE);
        for (i32 ty = top; ty <= bot; ty++) {
            CollisionType ct = TileAt(left, ty);
            f32 objSurf = (ct == COL_EMPTY) ? ObjectSolidSurface(left, ty) : -1.0f;
            // overlap: player body must enter the solid region [objSurf, tileBottom)
            bool objBlock = objSurf >= 0.0f
                && b->y < (f32)(ty * TILE_SIZE + TILE_SIZE)
                && b->y + PT_BODY_H > objSurf + 0.5f;
            if (IsSolid(ct) || ct == COL_HALF_BOTTOM || objBlock) {
                if (!objBlock) {
                    f32 tileTop = (f32)(ty * TILE_SIZE);
                    f32 surface = tileTop + (ct == COL_HALF_BOTTOM ? (f32)TILE_SIZE * 0.5f : 0.0f);
                    if (TryStepUp(b, surface)) return;
                }
                b->x  = (f32)((left + 1) * TILE_SIZE);
                b->vx = 0.0f;
                return;
            }
        }
    }
}

// Returns true if the player is adjacent to an OBJ_VENT tile.
static bool NearVent(i32* outTx, i32* outTy) {
    for (i32 ty = 0; ty < WORLD_HEIGHT_TILES; ty++) {
        for (i32 tx = 0; tx < WORLD_WIDTH_TILES; tx++) {
            if (gWorld.tiles[LAYER_OBJECTS][ty][tx] != OBJ_VENT) continue;
            f32 sx = (f32)(tx * TILE_SIZE), sy = (f32)(ty * TILE_SIZE);
            f32 dx = (s_body.x + PT_BODY_W * 0.5f) - (sx + (f32)TILE_SIZE * 0.5f);
            f32 dy = (s_body.y + PT_BODY_H * 0.5f) - (sy + (f32)TILE_SIZE * 0.5f);
            if (fabsf(dx) < (f32)TILE_SIZE * 0.7f && fabsf(dy) < (f32)TILE_SIZE * 0.7f) {
                if (outTx) *outTx = tx;
                if (outTy) *outTy = ty;
                return true;
            }
        }
    }
    return false;
}

// Returns true if the player AABB is within one tile of an OBJ_SIGN tile.
static bool NearSign(i32* outTx, i32* outTy) {
    for (i32 ty = 0; ty < WORLD_HEIGHT_TILES; ty++) {
        for (i32 tx = 0; tx < WORLD_WIDTH_TILES; tx++) {
            if (gWorld.tiles[LAYER_OBJECTS][ty][tx] != OBJ_SIGN) continue;
            f32 sx = (f32)(tx * TILE_SIZE), sy = (f32)(ty * TILE_SIZE);
            f32 dx = (s_body.x + PT_BODY_W * 0.5f) - (sx + (f32)TILE_SIZE * 0.5f);
            f32 dy = (s_body.y + PT_BODY_H * 0.5f) - (sy + (f32)TILE_SIZE * 0.5f);
            if (dx > -(f32)TILE_SIZE * 0.7f && dx < (f32)TILE_SIZE * 0.7f &&
                dy > -(f32)TILE_SIZE * 0.7f && dy < (f32)TILE_SIZE * 0.7f) {
                if (outTx) *outTx = tx;
                if (outTy) *outTy = ty;
                return true;
            }
        }
    }
    return false;
}

static void ResolveY(PhysBody* b) {
    f32 inset  = 1.0f;
    f32 sampleX[3] = {
        b->x + inset,
        b->x + PT_BODY_W * 0.5f,
        b->x + PT_BODY_W - inset,
    };

    if (b->vy >= 0.0f) {
        f32 feet = b->y + PT_BODY_H;
        i32 botMin = (i32)floorf((feet - (f32)TILE_SIZE) / (f32)TILE_SIZE);
        i32 botMax = (i32)floorf((feet + PT_SLOPE_SNAP)   / (f32)TILE_SIZE);
        f32 bestSurface = 1e9f;
        bool found = false;

        for (int s = 0; s < 3; s++) {
          for (i32 bot = botMin; bot <= botMax; bot++) {
            i32 tx = (i32)(sampleX[s] / (f32)TILE_SIZE);
            CollisionType ct = TileAt(tx, bot);

            f32 tileTop = (f32)(bot * TILE_SIZE);
            f32 surface = tileTop;

            if (ct == COL_EMPTY) {
                // buttons provide their own collision surface
                if (bot < 0 || bot >= WORLD_HEIGHT_TILES || tx < 0 || tx >= WORLD_WIDTH_TILES) continue;
                i32 obj = gWorld.tiles[LAYER_OBJECTS][bot][tx];
                if (obj == OBJ_BUTTON_UP)   surface = tileTop + (f32)TILE_SIZE * 0.50f;
                else if (obj == OBJ_BUTTON_DOWN) surface = tileTop + (f32)TILE_SIZE * 0.75f;
                else continue;
                if (b->dropThrough) continue;
                if (b->prevY + PT_BODY_H > surface + 2.0f) continue;
            } else if (IsSolid(ct)) {
                // skip if player is a full tile or more below surface — catches ceilings, allows fast falls
                if (b->y + PT_BODY_H >= surface + (f32)TILE_SIZE) continue;
            } else if (ct == COL_HALF_BOTTOM) {
                surface += (f32)TILE_SIZE * 0.5f;
            } else if (ct == COL_PLATFORM) {
                if (b->dropThrough) continue;
                if (b->prevY + PT_BODY_H > tileTop + 2.0f) continue;
            } else if (IsSlope(ct)) {
                f32 localX = sampleX[s] - (f32)(tx * TILE_SIZE);
                surface += SlopeSurfaceY(ct, localX);
                if (surface > tileTop + (f32)TILE_SIZE) continue;
            } else {
                continue;
            }

            if (b->y + PT_BODY_H < surface - PT_SLOPE_SNAP) continue;
            if (!found || surface < bestSurface) {
                bestSurface = surface;
                found = true;
            }
          }
        }

        if (found) {
            b->y      = bestSurface - PT_BODY_H;
            b->vy     = 0.0f;
            b->onGround = true;
        }
    } else {
        i32 topRow = (i32)(b->y / (f32)TILE_SIZE);
        i32 botRow = (i32)((b->y + PT_BODY_H - 0.5f) / (f32)TILE_SIZE);
        for (i32 ty = botRow; ty >= topRow; ty--) {
            for (int s = 0; s < 3; s++) {
                i32 tx = (i32)(sampleX[s] / (f32)TILE_SIZE);
                if (IsSolid(TileAt(tx, ty))) {
                    b->y  = (f32)((ty + 1) * TILE_SIZE);
                    b->vy = 0.0f;
                    return;
                }
            }
        }
    }
}

// ---- Crate tile collision ----
static void CrateResolveX(CrateBody* c) {
    i32 top = (i32)(c->y / (f32)TILE_SIZE);
    i32 bot = (i32)((c->y + PT_CRATE_SIZE - 0.5f) / (f32)TILE_SIZE);
    if (c->vx > 0.0f) {
        i32 right = (i32)((c->x + PT_CRATE_SIZE - 0.5f) / (f32)TILE_SIZE);
        for (i32 ty = top; ty <= bot; ty++) {
            CollisionType ct = TileAt(right, ty);
            if (IsSlope(ct)) {
                f32 localX = (c->x + PT_CRATE_SIZE) - (f32)(right * TILE_SIZE);
                f32 surfY  = (f32)(ty * TILE_SIZE) + SlopeSurfaceY(ct, localX);
                if (surfY < c->y + PT_CRATE_SIZE - 1.0f) {
                    c->x  = (f32)(right * TILE_SIZE) - PT_CRATE_SIZE;
                    c->vx = 0.0f;
                    return;
                }
                continue;
            }
            if (IsSolid(ct)) {
                c->x  = (f32)(right * TILE_SIZE) - PT_CRATE_SIZE;
                c->vx = 0.0f;
                return;
            }
        }
    } else if (c->vx < 0.0f) {
        i32 left = (i32)(c->x / (f32)TILE_SIZE);
        for (i32 ty = top; ty <= bot; ty++) {
            CollisionType ct = TileAt(left, ty);
            if (IsSlope(ct)) {
                f32 localX = c->x - (f32)(left * TILE_SIZE);
                f32 surfY  = (f32)(ty * TILE_SIZE) + SlopeSurfaceY(ct, localX);
                if (surfY < c->y + PT_CRATE_SIZE - 1.0f) {
                    c->x  = (f32)((left + 1) * TILE_SIZE);
                    c->vx = 0.0f;
                    return;
                }
                continue;
            }
            if (IsSolid(ct)) {
                c->x  = (f32)((left + 1) * TILE_SIZE);
                c->vx = 0.0f;
                return;
            }
        }
    }
}

static void CrateResolveY(CrateBody* c) {
    f32 inset = 1.0f;
    f32 sampleX[3] = {
        c->x + inset,
        c->x + PT_CRATE_SIZE * 0.5f,
        c->x + PT_CRATE_SIZE - inset,
    };

    if (c->vy >= 0.0f) {
        f32 feet   = c->y + PT_CRATE_SIZE;
        i32 botMin = (i32)floorf((feet - (f32)TILE_SIZE) / (f32)TILE_SIZE);
        i32 botMax = (i32)floorf((feet + PT_SLOPE_SNAP)   / (f32)TILE_SIZE);
        f32 bestSurface = 1e9f;
        bool found = false;

        for (i32 s = 0; s < 3; s++) {
            for (i32 bot = botMin; bot <= botMax; bot++) {
                i32 tx = (i32)(sampleX[s] / (f32)TILE_SIZE);
                CollisionType ct = TileAt(tx, bot);
                f32 tileTop = (f32)(bot * TILE_SIZE);
                f32 surface = tileTop;

                if (ct == COL_EMPTY) {
                    continue;
                } else if (IsSolid(ct)) {
                    if (c->y + PT_CRATE_SIZE >= surface + (f32)TILE_SIZE) continue;
                } else if (IsSlope(ct)) {
                    // Sample at the crate's leading edge for the slope surface
                    f32 localX = sampleX[s] - (f32)(tx * TILE_SIZE);
                    surface += SlopeSurfaceY(ct, localX);
                    if (surface > tileTop + (f32)TILE_SIZE) continue;
                } else if (ct == COL_HALF_BOTTOM) {
                    surface += (f32)TILE_SIZE * 0.5f;
                } else if (ct == COL_PLATFORM) {
                    continue;
                }

                if (c->y + PT_CRATE_SIZE < surface - PT_SLOPE_SNAP) continue;
                if (!found || surface < bestSurface) {
                    bestSurface = surface;
                    found = true;
                }
            }
        }

        if (found) {
            c->y        = bestSurface - PT_CRATE_SIZE;
            c->vy       = 0.0f;
            c->onGround = true;
        }
    } else {
        i32 topRow = (i32)(c->y / (f32)TILE_SIZE);
        i32 botRow = (i32)((c->y + PT_CRATE_SIZE - 0.5f) / (f32)TILE_SIZE);
        for (i32 ty = botRow; ty >= topRow; ty--) {
            for (i32 s = 0; s < 3; s++) {
                i32 tx = (i32)(sampleX[s] / (f32)TILE_SIZE);
                if (IsSolid(TileAt(tx, ty))) {
                    c->y  = (f32)((ty + 1) * TILE_SIZE);
                    c->vy = 0.0f;
                    return;
                }
            }
        }
    }
}

static void CratePhysStep(CrateBody* c, f32 dt) {
    c->vy += PT_GRAVITY * dt;
    if (c->vy > PT_MAX_FALL) c->vy = PT_MAX_FALL;

    c->x += c->vx * dt;
    CrateResolveX(c);

    c->prevY    = c->y;
    c->onGround = false;
    c->y += c->vy * dt;
    CrateResolveY(c);

    if (c->onGround)
        c->vx *= PT_CRATE_FRICTION;

    // Reset if fallen off screen
    if (c->y > SCR_H + 64) c->active = false;
}

// Crate vs crate horizontal separation (simple push-apart).
static void ResolveCrateVsCrates(i32 idx) {
    CrateBody* a = &s_crates[idx];
    for (i32 j = 0; j < s_crateCount; j++) {
        if (j == idx) continue;
        CrateBody* b = &s_crates[j];
        if (!b->active) continue;
        f32 ox = PT_CRATE_SIZE - fabsf(a->x - b->x);
        f32 oy = PT_CRATE_SIZE - fabsf(a->y - b->y);
        if (ox <= 0 || oy <= 0) continue;
        if (ox < oy) {
            f32 push = ox * 0.5f;
            if (a->x < b->x) { a->x -= push; b->x += push; }
            else             { a->x += push; b->x -= push; }
            f32 avg = (a->vx + b->vx) * 0.5f;
            a->vx = avg; b->vx = avg;
        } else {
            // vertical stack
            if (a->y < b->y) {
                b->y = a->y + PT_CRATE_SIZE;
                b->vy = 0.0f; b->onGround = true;
            } else {
                a->y = b->y + PT_CRATE_SIZE;
                a->vy = 0.0f; a->onGround = true;
            }
        }
    }
}

// Resolve player body against all active crates.
static void ResolvePlayerVsCrates(void) {
    f32 pw = PT_BODY_W, ph = PT_BODY_H;
    f32 cs = PT_CRATE_SIZE;
    s_isPushing = false;
    for (i32 i = 0; i < s_crateCount; i++) {
        CrateBody* c = &s_crates[i];
        if (!c->active) continue;

        f32 pCx = s_body.x + pw * 0.5f, pCy = s_body.y + ph * 0.5f;
        f32 cCx = c->x    + cs * 0.5f,  cCy = c->y    + cs * 0.5f;
        f32 ox  = (pw + cs) * 0.5f - fabsf(pCx - cCx);
        f32 oy  = (ph + cs) * 0.5f - fabsf(pCy - cCy);
        if (ox <= 0 || oy <= 0) continue;

        // Bias toward vertical resolution when falling onto a crate to prevent corner blipping
        bool preferVertical = (s_body.vy > 0.0f && pCy < cCy && oy < ox + 4.0f);
        if (!preferVertical && ox < oy) {
            // Horizontal contact — push crate
            f32 dir = (pCx < cCx) ? 1.0f : -1.0f;
            c->x  += dir * ox;
            c->vx  = dir * PT_CRATE_PUSH_VEL + s_body.vx * 0.6f;
            // Re-run X resolution so the pushed crate can't end up inside a slope
            CrateResolveX(c);
            // Push player back by any remaining overlap after crate correction
            f32 remainOx = (pw + cs) * 0.5f - fabsf((s_body.x + pw * 0.5f) - (c->x + cs * 0.5f));
            if (remainOx > 0.0f) {
                s_body.x -= dir * remainOx;
                s_body.vx = 0.0f;
            }
            s_isPushing = true;
        } else {
            // Vertical contact
            if (pCy < cCy) {
                s_body.y        = c->y - ph;
                s_body.vy       = 0.0f;
                s_body.onGround = true;
            } else {
                s_body.y  = c->y + cs;
                s_body.vy = 0.0f;
            }
        }
    }
}

static void PhysStep(PhysBody* b, f32 dt) {
    b->vy += PT_GRAVITY * dt;
    if (b->vy > PT_MAX_FALL) b->vy = PT_MAX_FALL;

    b->x += b->vx * dt;
    ResolveX(b);

    b->prevY    = b->y;
    b->onGround = false;
    b->y       += b->vy * dt;
    ResolveY(b);

    if (b->y > SCR_H + 32) {
        b->x = PT_SPAWN_X; b->y = PT_SPAWN_Y;
        b->vx = 0.0f; b->vy = 0.0f;
    }
}

// ---- Debug collision visualization ----
static void DrawCollisionDebug(void) {
    for (i32 ty = 0; ty < WORLD_HEIGHT_TILES; ty++) {
        for (i32 tx = 0; tx < WORLD_WIDTH_TILES; tx++) {
            CollisionType ct = TileAt(tx, ty);
            if (ct == COL_EMPTY) continue;

            i32 px = tx * TILE_SIZE;
            i32 py = ty * TILE_SIZE;

            if (IsSolid(ct)) {
                pd->graphics->fillRect(px, py, TILE_SIZE, TILE_SIZE, kColorWhite);
            } else if (ct == COL_PLATFORM) {
                pd->graphics->fillRect(px, py, TILE_SIZE, 3, kColorWhite);
            } else if (ct == COL_HALF_BOTTOM) {
                pd->graphics->fillRect(px, py + TILE_SIZE / 2, TILE_SIZE, TILE_SIZE / 2, kColorWhite);
            } else if (IsSlope(ct)) {
                // Draw slope as a filled triangle using scanlines
                for (i32 sx = 0; sx < TILE_SIZE; sx++) {
                    f32 surfY = SlopeSurfaceY(ct, (f32)sx);
                    i32 fillTop = py + (i32)surfY;
                    i32 fillH   = TILE_SIZE - (i32)surfY;
                    if (fillH > 0) pd->graphics->fillRect(px + sx, fillTop, 1, fillH, kColorWhite);
                }
            }
        }
    }
}

// Lincoln frame indices are 0-based (user counts from 1: idle=1-4, walk=5-10, run=11-14, jump=15-16, fall=17-18)
static void DefineAnimations(void) {
    AnimSequence seq;

    memset(&seq, 0, sizeof(seq));
    strncpy(seq.name, "idle", MAX_ANIM_NAME_LENGTH - 1);
    seq.playback   = ANIM_LOOP;
    seq.frameCount = 4;
    for (int i = 0; i < 4; i++) { seq.frames[i].frameIndex = i; seq.frames[i].duration = 0.18f; }
    AnimSet_AddSequence(&s_animSet, &seq);

    memset(&seq, 0, sizeof(seq));
    strncpy(seq.name, "walk", MAX_ANIM_NAME_LENGTH - 1);
    seq.playback   = ANIM_LOOP;
    seq.frameCount = 6;
    for (int i = 0; i < 6; i++) { seq.frames[i].frameIndex = 4 + i; seq.frames[i].duration = 0.085f; }
    AnimSet_AddSequence(&s_animSet, &seq);

    memset(&seq, 0, sizeof(seq));
    strncpy(seq.name, "run", MAX_ANIM_NAME_LENGTH - 1);
    seq.playback   = ANIM_LOOP;
    seq.frameCount = 4;
    for (int i = 0; i < 4; i++) { seq.frames[i].frameIndex = 10 + i; seq.frames[i].duration = 0.07f; }
    AnimSet_AddSequence(&s_animSet, &seq);

    memset(&seq, 0, sizeof(seq));
    strncpy(seq.name, "jump", MAX_ANIM_NAME_LENGTH - 1);
    seq.playback   = ANIM_LOOP;
    seq.frameCount = 2;
    for (int i = 0; i < 2; i++) { seq.frames[i].frameIndex = 14 + i; seq.frames[i].duration = 0.1f; }
    AnimSet_AddSequence(&s_animSet, &seq);

    memset(&seq, 0, sizeof(seq));
    strncpy(seq.name, "fall", MAX_ANIM_NAME_LENGTH - 1);
    seq.playback   = ANIM_LOOP;
    seq.frameCount = 2;
    for (int i = 0; i < 2; i++) { seq.frames[i].frameIndex = 16 + i; seq.frames[i].duration = 0.1f; }
    AnimSet_AddSequence(&s_animSet, &seq);

    memset(&seq, 0, sizeof(seq));
    strncpy(seq.name, "hurt", MAX_ANIM_NAME_LENGTH - 1);
    seq.playback      = ANIM_ONCE;
    seq.frameCount    = 1;
    seq.frames[0].frameIndex = 18; seq.frames[0].duration = 0.2f;
    AnimSet_AddSequence(&s_animSet, &seq);

    memset(&seq, 0, sizeof(seq));
    strncpy(seq.name, "crouch", MAX_ANIM_NAME_LENGTH - 1);
    seq.playback      = ANIM_ONCE;
    seq.frameCount    = 1;
    seq.frames[0].frameIndex = 19; seq.frames[0].duration = 0.1f;
    AnimSet_AddSequence(&s_animSet, &seq);
}

// ---- Screen callbacks ----

void PhysTestScreen_Init(void) {
    World_Init(pd, &gWorld, "assets/texture/tileset/collision");

    cstr paths[LAYER_COUNT] = {
        NULL,
        NULL,
        "assets/data/csv/test/test_map_Objects.csv",
        NULL,
        "assets/data/csv/test/test_map_Collision.csv"
    };
    if (!World_LoadCSV(pd, &gWorld, paths))
        LOG("PhysTest: failed to load room CSVs");

    s_objTable = Asset_LoadBitmapTable("assets/texture/tileset/BASE_TILES_OBJECTS");

    AnimSet_Init(&s_animSet);
    AnimState_Init(&s_animState);
    AnimSet_LoadTable(&s_animSet, "assets/texture/spritesheet/LincolnPlaydate");
    DefineAnimations();
    AnimState_Play(&s_animState, &s_animSet, "idle");
    s_animCur = PS_IDLE;

    // Find OBJ_PLAYER tile in the objects layer to use as spawn position
    f32 spawnX = PT_SPAWN_X, spawnY = PT_SPAWN_Y;
    for (i32 ty = 0; ty < WORLD_HEIGHT_TILES; ty++) {
        for (i32 tx = 0; tx < WORLD_WIDTH_TILES; tx++) {
            if (gWorld.tiles[LAYER_OBJECTS][ty][tx] == OBJ_PLAYER) {
                spawnX = (f32)(tx * TILE_SIZE);
                spawnY = (f32)(ty * TILE_SIZE);
                goto spawn_found;
            }
        }
    }
    spawn_found:
    s_body = (PhysBody){ .x = spawnX, .y = spawnY, .facingRight = true };
    s_stamina      = 1.0f;
    s_exhaustTimer = 0.0f;
    s_isPushing    = false;

    // Scan object layer for crates; lift them out of the tile map into dynamic bodies
    s_crateCount = 0;
    for (i32 ty = 0; ty < WORLD_HEIGHT_TILES && s_crateCount < PT_MAX_CRATES; ty++) {
        for (i32 tx = 0; tx < WORLD_WIDTH_TILES && s_crateCount < PT_MAX_CRATES; tx++) {
            if (gWorld.tiles[LAYER_OBJECTS][ty][tx] != OBJ_CRATE) continue;
            CrateBody* cr  = &s_crates[s_crateCount++];
            cr->x          = (f32)(tx * TILE_SIZE);
            cr->y          = (f32)(ty * TILE_SIZE);
            cr->vx         = 0.0f;
            cr->vy         = 0.0f;
            cr->onGround   = false;
            cr->active     = true;
            gWorld.tiles[LAYER_OBJECTS][ty][tx] = -1;  // remove static tile
        }
    }
}

void PhysTestScreen_Update(f32 deltaTime) {
    if (Signage_IsActive()) { Signage_Update(deltaTime); return; }

    bool left       = Input_IsDown(&inputManager, INPUT_LEFT);
    bool right      = Input_IsDown(&inputManager, INPUT_RIGHT);
    bool leftPress  = Input_IsPressed(&inputManager, INPUT_LEFT);
    bool rightPress = Input_IsPressed(&inputManager, INPUT_RIGHT);
    bool down      = Input_IsDown(&inputManager, INPUT_DOWN);
    bool downPress = Input_IsPressed(&inputManager, INPUT_DOWN);
    bool isCrouching = down;

    // Double-tap DOWN to drop through platforms
    s_body.tapDownFrames++;
    if (downPress) {
        if (s_body.tapDownFrames <= PT_DOUBLE_TAP_FRAMES)
            s_body.dropThrough = true;
        s_body.tapDownFrames = 0;
    }
    if (!down) s_body.dropThrough = false;

    // Double-tap run detection
    s_body.tapFrames++;
    if (leftPress) {
        if (s_body.tapDir == -1 && s_body.tapFrames <= PT_DOUBLE_TAP_FRAMES)
            s_body.isRunning = true;
        s_body.tapDir    = -1;
        s_body.tapFrames = 0;
    } else if (rightPress) {
        if (s_body.tapDir == 1 && s_body.tapFrames <= PT_DOUBLE_TAP_FRAMES)
            s_body.isRunning = true;
        s_body.tapDir    = 1;
        s_body.tapFrames = 0;
    }
    // cancel run when direction released
    if (!left && !right) s_body.isRunning = false;

    f32 speed = s_body.isRunning ? PT_RUN_SPEED : PT_MOVE_SPEED;
    if (s_inVent) {
        s_body.vx = 0.0f;
        s_body.vy = 0.0f;
    } else {
        s_body.vx = (!(isCrouching && s_body.onGround) && right) ? speed
                  : (!(isCrouching && s_body.onGround) && left)  ? -speed
                  : 0.0f;
        if (right) s_body.facingRight = true;
        if (left)  s_body.facingRight = false;
    }

    // Clamp to push speed NOW so PhysStep integrates the right velocity
    if (s_isPushing && s_body.onGround) {
        f32 maxPush = (s_exhaustTimer > 0.0f) ? 0.0f : PT_PUSH_SPEED;
        if (s_body.vx >  maxPush) s_body.vx =  maxPush;
        if (s_body.vx < -maxPush) s_body.vx = -maxPush;
    }

    // Stamina drain/regen — evaluated after velocity set, applied after crate resolve below
    if (s_isPushing && s_body.onGround) {
        s_exhaustTimer -= deltaTime;
        if (s_exhaustTimer < 0.0f) s_exhaustTimer = 0.0f;
        if (s_exhaustTimer == 0.0f) {
            s_stamina -= PT_STAMINA_DRAIN * deltaTime;
            if (s_stamina <= 0.0f) {
                s_stamina      = 0.0f;
                s_exhaustTimer = PT_STAMINA_EXHAUST_T;
            }
        }
    } else {
        s_stamina += PT_STAMINA_REGEN * deltaTime;
        if (s_stamina > 1.0f) s_stamina = 1.0f;
    }

    if (!s_inVent && Input_IsPressed(&inputManager, INPUT_A)) {
        if (s_body.onGround) {
            s_body.vy            = PT_JUMP_VEL;
            s_body.canDoubleJump = true;
        } else if (s_body.canDoubleJump) {
            s_body.vy            = PT_DOUBLE_JUMP_VEL;
            s_body.canDoubleJump = false;
        }
    }
    if (s_body.onGround) s_body.canDoubleJump = true;

    // Step crates first so player resolution can land on them
    for (i32 i = 0; i < s_crateCount; i++) {
        if (s_crates[i].active) CratePhysStep(&s_crates[i], deltaTime);
    }
    for (i32 i = 0; i < s_crateCount; i++) {
        if (s_crates[i].active) ResolveCrateVsCrates(i);
    }

    if (!s_inVent) PhysStep(&s_body, deltaTime);
    ResolvePlayerVsCrates();

    // Button press
    if (s_body.onGround) {
        i32 btx = (i32)((s_body.x + PT_BODY_W * 0.5f) / (f32)TILE_SIZE);
        i32 bty = (i32)((s_body.y + PT_BODY_H - 1.0f)  / (f32)TILE_SIZE);
        if (bty >= 0 && bty < WORLD_HEIGHT_TILES &&
            gWorld.tiles[LAYER_OBJECTS][bty][btx] == OBJ_BUTTON_UP) {
            gWorld.tiles[LAYER_OBJECTS][bty][btx] = OBJ_BUTTON_DOWN;
            s_buttonActivated = true;
        }
    }

    // Spring launch
    if (s_body.onGround) {
        i32 ftx = (i32)((s_body.x + PT_BODY_W * 0.5f) / (f32)TILE_SIZE);
        i32 fty = (i32)((s_body.y + PT_BODY_H - 1.0f)  / (f32)TILE_SIZE);
        if (fty < WORLD_HEIGHT_TILES && gWorld.tiles[LAYER_OBJECTS][fty][ftx] == OBJ_SPRING_A) {
            s_body.vy           = PT_SPRING_VEL;
            s_body.onGround     = false;
            s_body.canDoubleJump = true;
            s_springTx = ftx; s_springTy = fty; s_springFrames = PT_SPRING_FRAMES;
        }
    }
    if (s_springFrames > 0) s_springFrames--;

    PlayerAnimState next = PS_IDLE;
    if (!s_body.onGround)             next = (s_body.vy < 0.0f) ? PS_JUMP : PS_FALL;
    else if (isCrouching)             next = PS_CROUCH;
    else if (s_body.vx != 0.0f)       next = s_body.isRunning ? PS_RUN : PS_WALK;

    if (next != s_animCur) {
        s_animCur = next;
        switch (next) {
            case PS_IDLE:   AnimState_Play(&s_animState, &s_animSet, "idle");   break;
            case PS_WALK:   AnimState_Play(&s_animState, &s_animSet, "walk");   break;
            case PS_RUN:    AnimState_Play(&s_animState, &s_animSet, "run");    break;
            case PS_CROUCH: AnimState_Play(&s_animState, &s_animSet, "crouch"); break;
            case PS_JUMP:   AnimState_Play(&s_animState, &s_animSet, "jump");   break;
            case PS_FALL:   AnimState_Play(&s_animState, &s_animSet, "fall");   break;
        }
    }
    AnimState_Update(&s_animState, &s_animSet, deltaTime);

    // Sign interaction — open on UP press near a sign
    i32 stx, sty;
    if (NearSign(&stx, &sty) && Input_IsPressed(&inputManager, INPUT_UP))
        Signage_Show("Notice", "This is a test sign. Press { or } to dismiss.");

    // Vent interaction
    i32 vtx, vty;
    if (Input_IsPressed(&inputManager, INPUT_UP)) {
        if (s_inVent) {
            // Exit vent — pop player out just below the vent tile
            s_body.x    = (f32)(s_ventTx * TILE_SIZE) + (TILE_SIZE - PT_BODY_W) * 0.5f;
            s_body.y    = (f32)((s_ventTy + 1) * TILE_SIZE);
            s_body.vx   = 0.0f;
            s_body.vy   = 0.0f;
            s_inVent    = false;
            s_ventTx    = -1;
            s_ventTy    = -1;
        } else if (!s_inVent && NearVent(&vtx, &vty)) {
            // Enter vent — snap player into vent tile and freeze
            s_body.x    = (f32)(vtx * TILE_SIZE) + (TILE_SIZE - PT_BODY_W) * 0.5f;
            s_body.y    = (f32)(vty * TILE_SIZE) + (TILE_SIZE - PT_BODY_H) * 0.5f;
            s_body.vx   = 0.0f;
            s_body.vy   = 0.0f;
            s_inVent    = true;
            s_ventTx    = vtx;
            s_ventTy    = vty;
        }
    }

    if (Input_IsPressed(&inputManager, INPUT_B))
        SwitchScreen(&screenManager, SS_TEST_WORLD);
}

void PhysTestScreen_Draw(void) {
    pd->graphics->clear(kColorBlack);

    // 1. Debug collision geometry (white shapes on black)
    DrawCollisionDebug();

    // 3. Objects from CSV — skip OBJ_PLAYER (spawn marker), use BlackTransparent so background shows through
    if (s_objTable) {
        pd->graphics->setDrawMode(kDrawModeBlackTransparent);
        for (i32 ty = 0; ty < WORLD_HEIGHT_TILES; ty++) {
            for (i32 tx = 0; tx < WORLD_WIDTH_TILES; tx++) {
                i32 id = gWorld.tiles[LAYER_OBJECTS][ty][tx];
                if (id <= 0) continue;  // skip empty (-1) and OBJ_PLAYER (0)
                // Show compressed spring while active
                if (id == OBJ_SPRING_A && s_springFrames > 0 && tx == s_springTx && ty == s_springTy)
                    id = OBJ_SPRING_B;
                LCDBitmap* bmp = pd->graphics->getTableBitmap(s_objTable, id);
                if (bmp) pd->graphics->drawBitmap(bmp, tx * TILE_SIZE, ty * TILE_SIZE, kBitmapUnflipped);
            }
        }
        pd->graphics->setDrawMode(kDrawModeCopy);
    }

    // 3b. Dynamic crates (drawn after static objects, before player)
    if (s_objTable) {
        pd->graphics->setDrawMode(kDrawModeBlackTransparent);
        for (i32 i = 0; i < s_crateCount; i++) {
            if (!s_crates[i].active) continue;
            LCDBitmap* bmp = pd->graphics->getTableBitmap(s_objTable, OBJ_CRATE);
            if (bmp) pd->graphics->drawBitmap(bmp,
                (i32)s_crates[i].x, (i32)s_crates[i].y, kBitmapUnflipped);
        }
        pd->graphics->setDrawMode(kDrawModeCopy);
    }

    // 4. Player sprite — hidden while inside a vent
    if (!s_inVent) {
    LCDBitmap* bmp = AnimState_GetCurrentBitmap(&s_animState, &s_animSet);
    if (bmp) {
        Vec2 off  = AnimState_GetCurrentOffset(&s_animState, &s_animSet);
        LCDBitmapFlip flip = s_body.facingRight ? kBitmapUnflipped : kBitmapFlippedX;
        pd->graphics->setDrawMode(kDrawModeBlackTransparent);
        pd->graphics->drawBitmap(bmp,
            (i32)(s_body.x - 3.0f) + (i32)off.x,
            (i32)(s_body.y - 2.0f) + (i32)off.y,
            flip);
        pd->graphics->setDrawMode(kDrawModeCopy);
    }
    }

    if (s_buttonActivated)
        pd->graphics->fillRect(SCR_W - 16, 4, 12, 12, kColorWhite);

    // Stamina bar (top-left)
    {
        i32 barX = 4, barY = 4, barW = 40, barH = 5;
        pd->graphics->drawRect(barX - 1, barY - 1, barW + 2, barH + 2, kColorWhite);
        i32 fill = (i32)(s_stamina * (f32)barW);
        if (fill > 0) pd->graphics->fillRect(barX, barY, fill, barH, kColorWhite);
        // Flash bar outline when exhausted
        if (s_exhaustTimer > 0.0f && (i32)(s_exhaustTimer * 10.0f) % 2 == 0)
            pd->graphics->fillRect(barX - 1, barY - 1, barW + 2, barH + 2, kColorXOR);
    }

    DrawIconText("{ jump  ` drop-thru  } back", 4, SCR_H - 12, 2, kColorWhite, 12);

    // UP prompts over nearby interactive objects
    i32 stx, sty;
    if (!Signage_IsActive() && NearSign(&stx, &sty)) {
        i32 px = stx * TILE_SIZE + (TILE_SIZE - 8) / 2;
        i32 py = sty * TILE_SIZE - 10;
        DrawIconText("^", px, py, 2, kColorWhite, 10);
    }
    i32 vtx, vty;
    if (!s_inVent && NearVent(&vtx, &vty)) {
        i32 px = vtx * TILE_SIZE + (TILE_SIZE - 8) / 2;
        i32 py = vty * TILE_SIZE - 10;
        DrawIconText("^", px, py, 2, kColorWhite, 10);
    }
    if (s_inVent) {
        i32 px = s_ventTx * TILE_SIZE + (TILE_SIZE - 8) / 2;
        i32 py = s_ventTy * TILE_SIZE - 10;
        DrawIconText("^", px, py, 2, kColorWhite, 10);
    }

    // Sign box drawn last (on top of everything)
    Signage_Draw();
}

void PhysTestScreen_Unload(void) {
    World_Free(pd, &gWorld);
    AnimSet_Free(&s_animSet);
    if (s_objTable) {
        Asset_FreeBitmapTable(s_objTable);
        s_objTable = NULL;
    }
}
