// written by diskodev
// engine/note.c
#include "note.h"
#include "text.h"
#include "input.h"
#include "dialogue.h"
#include "audio.h"

extern PlaydateAPI* pd;
extern LCDFont* fontFamily[4];
extern InputManager inputManager;
extern AudioManager audioManager;

#define NOTE_W       280
#define NOTE_H       180
#define NOTE_PAD       8
#define NOTE_FONT_TTL  0  // octosale.regular
#define NOTE_FONT_BODY 1  // resmont.light
#define NOTE_RADIUS    3

static bool     s_active;
static bool     s_done;
static GameNote s_note;
static i32      s_page;       // current first-line index
static i32      s_pageCount;
static i32      s_bx, s_by;

void Note_Show(const GameNote* note) {
    if (!note) return;
    s_note   = *note;
    s_page   = 0;
    s_active = true;
    s_done   = false;

    i32 pages = (note->lineCount + NOTE_LINES_PER_PG - 1) / NOTE_LINES_PER_PG;
    s_pageCount = pages > 0 ? pages : 1;

    s_bx = (SCR_W - NOTE_W) / 2;
    s_by = (SCR_H - NOTE_H) / 2;
    PlaySFX(&audioManager, "assets/audio/sfx/textbox_appear", 80, false);
}

void Note_Dismiss(void) { s_active = false; s_done = true; }
bool Note_IsActive(void) { return s_active; }
bool Note_IsDone(void)   { return s_done; }

void Note_Update(f32 deltaTime) {
    (void)deltaTime;
    if (!s_active) return;

    if (Input_IsPressed(&inputManager, INPUT_A)) {
        PlaySFX(&audioManager, "assets/audio/sfx/textbox_proceed", 70, false);
        if (s_page + NOTE_LINES_PER_PG < s_note.lineCount) {
            s_page += NOTE_LINES_PER_PG;
        } else {
            s_active = false;
            s_done   = true;
        }
    }
    if (Input_IsPressed(&inputManager, INPUT_B)) {
        PlaySFX(&audioManager, "assets/audio/sfx/menu_back", 70, false);
        s_active = false;
        s_done   = true;
    }
}

void Note_Draw(void) {
    if (!s_active) return;

    i32 bx = s_bx, by = s_by;

    // paper: white fill + black border
    pd->graphics->fillRoundRect(bx,     by,     NOTE_W,     NOTE_H,     NOTE_RADIUS,     kColorBlack);
    pd->graphics->fillRoundRect(bx + 2, by + 2, NOTE_W - 4, NOTE_H - 4, NOTE_RADIUS - 1, kColorWhite);

    LCDFont* tf = fontFamily[NOTE_FONT_TTL];
    LCDFont* bf = fontFamily[NOTE_FONT_BODY];
    i32 tlh = tf ? pd->graphics->getFontHeight(tf) + 3 : 14;
    i32 blh = bf ? pd->graphics->getFontHeight(bf) + 3 : 13;

    i32 cy = by + NOTE_PAD;

    // title + underline
    if (s_note.title[0]) {
        DrawText(s_note.title, bx + NOTE_PAD, cy, NOTE_FONT_TTL, kColorBlack);
        cy += tlh;
        pd->graphics->drawLine(bx + NOTE_PAD, cy, bx + NOTE_W - NOTE_PAD, cy, 1, kColorBlack);
        cy += 4;
    }

    // body lines for this page
    i32 end = s_page + NOTE_LINES_PER_PG;
    if (end > s_note.lineCount) end = s_note.lineCount;
    for (i32 i = s_page; i < end; i++) {
        DrawIconText(s_note.lines[i], bx + NOTE_PAD, cy, NOTE_FONT_BODY, kColorBlack, blh);
        cy += blh;
    }

    // page indicator and controls at bottom
    i32 footY = by + NOTE_H - NOTE_PAD - blh;
    if (s_pageCount > 1) {
        char pg[16];
        snprintf(pg, sizeof(pg), "%d/%d", s_page / NOTE_LINES_PER_PG + 1, s_pageCount);
        DrawText(pg, bx + NOTE_PAD, footY, NOTE_FONT_BODY, kColorBlack);
    }

    // A = next/close, B = close icons
    bool hasNext = s_page + NOTE_LINES_PER_PG < s_note.lineCount;
    cstr aLabel  = hasNext ? " next" : " close";
    i32 aLabelW  = 18 + (i32)GetTextWidth(aLabel, NOTE_FONT_BODY);
    i32 bLabelW  = 18 + (i32)GetTextWidth(" close", NOTE_FONT_BODY);
    i32 hintsX   = bx + NOTE_W - NOTE_PAD - aLabelW - 4 - bLabelW;
    DialogueBox_DrawBtn(true,  hintsX, footY - 2);
    DrawText(aLabel, hintsX + 18, footY, 2, kColorBlack);
    hintsX += aLabelW + 4;
    DialogueBox_DrawBtn(false, hintsX, footY - 2);
    DrawText(" close", hintsX + 18, footY, 2, kColorBlack);
}
